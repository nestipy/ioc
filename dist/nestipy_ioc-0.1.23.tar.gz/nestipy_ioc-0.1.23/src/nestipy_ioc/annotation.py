class Annotation:
    def __init__(self, metadata=None, *args):
        self.metadata = metadata
        self.args = args
